// multiply.mjs

export default function multiply(a, b) {
  return a * b
}