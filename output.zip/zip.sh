zip -r output.zip . -x node_modules/**\* doc/**\* data/**\* in/**\* sets/**\* .git/**\* *.zip
