zip -r out/sources.zip . -x node_modules/**\* doc/**\* data/**\* in/**\* sets/**\* .git/**\* *.zip
